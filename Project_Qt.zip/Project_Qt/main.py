import sys
#        MainWindow.setFixedSize(1240, 620)
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget
from MainWindow import Ui_MainWindow
from widget import Ui_Form

ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
ALPHABET1 = "abcdefghijklmnopqrstuvwxyz"
RUSALPHABET = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
RUSALPHABET1 = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"


class MainWidget(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.textEdit_output.setReadOnly(True)
        self.ROT1.clicked.connect(self.func_rot1)
        self.Caesar_cipher.clicked.connect(self.func_caesar_cipher)
        self.Playfair_cipher.clicked.connect(self.func_playfair_cipher)
        self.Atbash_cipher.clicked.connect(self.func_atbash_cipher)
        self.Vernam_cipher.clicked.connect(self.func_vernam_cipher)

    def func_rot1(self):
        self.textEdit_output.clear()
        try:
            if self.textEdit_input.toPlainText() == "":
                raise SyntaxError
            arr = []
            for i in self.textEdit_input.toPlainText():
                if i in ALPHABET:
                    n = (ALPHABET.find(i) + 1) % 26
                    arr.append(ALPHABET[n])
                elif i in ALPHABET1:
                    n = (ALPHABET1.find(i) + 1) % 26
                    arr.append(ALPHABET1[n])
                elif i in RUSALPHABET:
                    n = (RUSALPHABET.find(i) + 1) % 33
                    arr.append(RUSALPHABET[n])
                elif i in RUSALPHABET1:
                    n = (RUSALPHABET1.find(i) + 1) % 33
                    arr.append(RUSALPHABET1[n])
                else:
                    arr.append(i)
            string = ''.join(arr)
            self.textEdit_output.append(string)
        except SyntaxError:
            self.err = "error_input"
            self.w2 = Window2(self.err)
            self.w2.show()

    def func_caesar_cipher(self):
        self.textEdit_output.clear()
        try:
            if self.textEdit_key.toPlainText() == "" or self.textEdit_input.toPlainText() == "":
                raise SyntaxError
            if not self.textEdit_key.toPlainText().isdigit():
                raise TypeError
            arr = []
            for i in self.textEdit_input.toPlainText():
                if i in ALPHABET:
                    n = (ALPHABET.find(i) + int(self.textEdit_key.toPlainText())) % 26
                    arr.append(ALPHABET[n])
                elif i in ALPHABET1:
                    n = (ALPHABET1.find(i) + int(self.textEdit_key.toPlainText())) % 26
                    arr.append(ALPHABET1[n])
                elif i in RUSALPHABET:
                    n = (RUSALPHABET.find(i) + int(self.textEdit_key.toPlainText())) % 33
                    arr.append(RUSALPHABET[n])
                elif i in RUSALPHABET1:
                    n = (RUSALPHABET1.find(i) + int(self.textEdit_key.toPlainText())) % 33
                    arr.append(RUSALPHABET1[n])
                else:
                    arr.append(i)
            string = ''.join(arr)
            self.textEdit_output.append(string)
        except TypeError:
            self.err = "type_error_key"
            self.w2 = Window2(self.err)
            self.w2.show()
        except SyntaxError:
            self.err = "error"
            self.w2 = Window2(self.err)
            self.w2.show()

    def func_playfair_cipher(self):
        self.textEdit_output.clear()
        try:
            def func_find(element, matrix):
                for i in range(len(matrix)):
                    for j in range(len(matrix[i])):
                        if matrix[i][j] == element:
                            return i, j

            def func_cords(cor_1, cor_2, arr_last_f, arr_a):
                if cor_1[0] == cor_2[0]:
                    arr_last_f.append(arr_a[cor_1[0]][(cor_1[1] + 1) % 5])
                    arr_last_f.append(arr_a[cor_2[0]][(cor_2[1] + 1) % 5])
                elif cor_1[1] == cor_2[1]:
                    arr_last_f.append(arr_a[(cor_1[0] + 1) % 5][cor_1[1]])
                    arr_last_f.append(arr_a[(cor_2[0] + 1) % 5][cor_2[1]])
                else:
                    arr_last_f.append(arr_a[cor_1[0]][cor_2[1]])
                    arr_last_f.append(arr_a[cor_2[0]][cor_1[1]])

            def func_cords_rus(cor_1, cor_2, arr_last_f, arr_a):
                if cor_1[0] == cor_2[0]:
                    arr_last_f.append(arr_a[cor_1[0]][(cor_1[1] + 1) % 8])
                    arr_last_f.append(arr_a[cor_2[0]][(cor_2[1] + 1) % 8])
                elif cor_1[1] == cor_2[1]:
                    arr_last_f.append(arr_a[(cor_1[0] + 1) % 4][cor_1[1]])
                    arr_last_f.append(arr_a[(cor_2[0] + 1) % 4][cor_2[1]])
                else:
                    arr_last_f.append(arr_a[cor_1[0]][cor_2[1]])
                    arr_last_f.append(arr_a[cor_2[0]][cor_1[1]])

            if self.textEdit_key.toPlainText() == "" or self.textEdit_input.toPlainText() == "":
                raise SyntaxError
            if self.textEdit_key.toPlainText()[0] in ALPHABET or \
                    self.textEdit_key.toPlainText()[0] in ALPHABET1:
                arr = [[], [], [], [], []]
                arr2_fake = [i for i in ''.join(str(self.textEdit_key.toPlainText()).lower().split())]
                arr2 = []
                for i in arr2_fake:
                    if i not in arr2 and i != 'j':
                        arr2.append(i)
                    elif i == 'j' and 'i' not in arr2:
                        arr2.append('i')
                arr3 = [i if i != 'j' else 'i' for i in ''.join(str(self.textEdit_input.toPlainText()).lower().split())]
                arr_last = []
                a = int()
                b = int()
                t = False
                if not ''.join(arr3).isalpha() or not ''.join(arr2).isalpha():
                    raise TypeError
                for i in range(5):
                    for j in range(5):
                        if i * 5 + j < len(arr2):
                            if arr2[i * 5 + j] in RUSALPHABET1:
                                raise TypeError
                            else:
                                arr[i].append(arr2[i * 5 + j])
                        else:
                            a = i
                            b = j
                            t = True
                            break
                    if t:
                        break
                for s in range(5):
                    for j in range(5):
                        if s * 5 + j >= a * 5 + b:
                            for k in ALPHABET1:
                                if k not in arr[0] and k not in arr[1] and k not in arr[2] and k not in arr[3] \
                                        and k not in arr[4] and k != 'j':
                                    arr[s].append(k)
                                    break
                for i in range(1, len(arr3), 2):
                    if arr3[i] in RUSALPHABET1 or arr3[i - 1] in RUSALPHABET1:
                        raise TypeError
                    cor1 = func_find(arr3[i - 1], arr)
                    cor_x = func_find('x', arr)
                    cor2 = func_find(arr3[i], arr)
                    if cor1 == cor2:
                        cor2 = cor_x
                    if cor1 == cor2:
                        cor_q = func_find('q', arr)
                        cor2 = cor_q
                    func_cords(cor1, cor2, arr_last, arr)
                    if i == len(arr3) - 2:
                        if arr3[i + 1] in RUSALPHABET1:
                            raise TypeError
                        cor3 = func_find(arr3[i + 1], arr)
                        if cor3 == cor_x:
                            cor_q = func_find('q', arr)
                            func_cords(cor3, cor_q, arr_last, arr)
                        else:
                            func_cords(cor3, cor_x, arr_last, arr)
                string = ''.join(arr_last)
                self.textEdit_output.append(string.upper())
            else:
                arr = [[], [], [], []]
                arr2_fake = [i for i in ''.join(str(self.textEdit_key.toPlainText()).lower().split())]
                arr2 = []
                for i in arr2_fake:
                    if i not in arr2 and i != 'ъ':
                        arr2.append(i)
                    elif i == 'ъ' and 'ь' not in arr2:
                        arr2.append('ь')
                arr3 = [i if i != 'ъ' else 'ь' for i in ''.join(str(self.textEdit_input.toPlainText()).lower().split())]
                arr_last = []
                a = int()
                b = int()
                t = False
                if not ''.join(arr3).isalpha() or not ''.join(arr2).isalpha():
                    raise TypeError
                for i in range(4):
                    for j in range(8):
                        if i * 8 + j < len(arr2):
                            if arr2[i * 8 + j] in ALPHABET1:
                                raise TypeError
                            else:
                                arr[i].append(arr2[i * 8 + j])
                        else:
                            a = i
                            b = j
                            t = True
                            break
                    if t:
                        break
                for s in range(4):
                    for j in range(8):
                        if s * 8 + j >= a * 8 + b:
                            for k in RUSALPHABET1:
                                if k not in arr[0] and k not in arr[1] and k not in arr[2] and \
                                        k not in arr[3] and k != 'ъ':
                                    arr[s].append(k)
                                    break
                for i in range(1, len(arr3), 2):
                    if arr3[i] in ALPHABET1 or arr3[i - 1] in ALPHABET1:
                        raise TypeError
                    cor1 = func_find(arr3[i - 1], arr)
                    cor_x = func_find('х', arr)
                    cor2 = func_find(arr3[i], arr)
                    if cor1 == cor2:
                        cor2 = cor_x
                    if cor1 == cor2:
                        cor_q = func_find('й', arr)
                        cor2 = cor_q
                    func_cords_rus(cor1, cor2, arr_last, arr)
                    if i == len(arr3) - 2:
                        if arr3[i + 1] in ALPHABET1:
                            raise TypeError
                        cor3 = func_find(arr3[i + 1], arr)
                        if cor3 == cor_x:
                            cor_q = func_find('й', arr)
                            func_cords_rus(cor3, cor_q, arr_last, arr)
                        else:
                            func_cords_rus(cor3, cor_x, arr_last, arr)
                string = ''.join(arr_last)
                self.textEdit_output.append(string.upper())

        except TypeError:
            self.err = "type_error"
            self.w2 = Window2(self.err)
            self.w2.show()
        except SyntaxError:
            self.err = "error"
            self.w2 = Window2(self.err)
            self.w2.show()

    def func_atbash_cipher(self):
        self.textEdit_output.clear()
        try:
            if self.textEdit_input.toPlainText() == "":
                raise SyntaxError
            arr = []
            for i in self.textEdit_input.toPlainText():
                if i in ALPHABET:
                    n = 26 - ALPHABET.find(i) - 1
                    arr.append(ALPHABET[n])
                elif i in ALPHABET1:
                    n = 26 - ALPHABET1.find(i) - 1
                    arr.append(ALPHABET1[n])
                elif i in RUSALPHABET:
                    n = 33 - RUSALPHABET.find(i) - 1
                    arr.append(RUSALPHABET[n])
                elif i in RUSALPHABET1:
                    n = 33 - RUSALPHABET1.find(i) - 1
                    arr.append(RUSALPHABET1[n])
                else:
                    arr.append(i)
            string = ''.join(arr)
            self.textEdit_output.append(string)
        except SyntaxError:
            self.err = "error_input"
            self.w2 = Window2(self.err)
            self.w2.show()

    def func_vernam_cipher(self):
        self.textEdit_output.clear()
        try:
            if self.textEdit_key.toPlainText() == "" or self.textEdit_input.toPlainText() == "":
                raise SyntaxError
            a = self.textEdit_input.toPlainText()
            k = self.textEdit_key.toPlainText()
            arr = []
            arr_k = []
            arr_last = []
            s_last = str()
            s_last_last = str()
            for i in a:
                arr_mini = []
                if len(bin(ord(i))[2:]) == 8:
                    arr.append(bin(ord(i))[2:])
                else:
                    s = str()
                    while len(s) + len(bin(ord(i))[2:]) != 8:
                        s += '0'
                    s += bin(ord(i))[2:]
                    arr.append(s)
            for i in k:
                arr_mini = []
                if len(bin(ord(i))[2:]) == 8:
                    arr_k.append(bin(ord(i))[2:])
                else:
                    s = str()
                    while len(s) + len(bin(ord(i))[2:]) != 8:
                        s += '0'
                    s += bin(ord(i))[2:]
                    arr_k.append(s)
            for i in range(len(arr)):
                s_last = str()
                for j in range(8):
                    s1 = arr[i]
                    s2 = arr_k[i % len(arr_k)]
                    if s1[j] != s2[j]:
                        s_last += '1'
                    else:
                        s_last += '0'
                arr_last.append(s_last)
            for i in arr_last:
                s_last_last += str(chr(int(i, base=2)))
            self.textEdit_output.append(s_last_last)
        except SyntaxError:
            self.err = "error"
            self.w2 = Window2(self.err)
            self.w2.show()


class Window2(QWidget, Ui_Form):
    def __init__(self, err):
        super().__init__()
        self.setupUi_widget(self)
        self.textEdit.setReadOnly(True)
        if err == "type_error":
            self.func_type_error()
        if err == "error":
            self.func_error()
        if err == "error_input":
            self.func_error_input()
        if err == "type_error_key":
            self.func_type_error_key()

    def func_type_error(self):
        self.textEdit.append("You can enter only symbols which from the Russian or English alphabet")

    def func_error(self):
        self.textEdit.append("You must enter \'input\' and \'key\'")

    def func_error_input(self):
        self.textEdit.append("You must enter \'input\'")

    def func_type_error_key(self):
        self.textEdit.append("You can enter only a number in the key")


app = QApplication(sys.argv)
ex = MainWidget()
ex.show()
sys.exit(app.exec_())
